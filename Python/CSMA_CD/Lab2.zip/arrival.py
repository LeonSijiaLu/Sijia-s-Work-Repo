class ArrivalEvent:
    def __init__(self, event_time):
        self.event_time = event_time   # The arrival time of each packet, it will be the element of eventQueue of Nodes